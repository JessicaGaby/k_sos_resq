const express = require('express');
const { Mostrar, mandar } = require('../controller/login.controller');

const router = express.Router();

router.get ('/login', Mostrar)
router.post ('/login', mandar)

module.exports = router